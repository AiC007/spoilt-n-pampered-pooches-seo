#!/bin/bash

# Placeholder Image Generator for Spoilt N Pampered Pooches
# Creates optimised placeholder images with proper dimensions and file sizes

# Check if ImageMagick is installed
if ! command -v convert &> /dev/null; then
    echo "ImageMagick not found. Installing via Homebrew..."
    brew install imagemagick
fi

# Create images directory if it doesn't exist
mkdir -p images

# Color scheme
BRAND_BLUE="#2E5C8F"
BRAND_GREEN="#4A7C59"
LIGHT_GREY="#F5F5F5"
TEXT_COLOR="#333333"

# Service Images (800x600px)
echo "Creating service placeholder images..."

# Dog Grooming Service
convert -size 800x600 xc:"$BRAND_BLUE" \
    -fill white -pointsize 48 -gravity center \
    -annotate +0-50 "Professional Dog" \
    -annotate +0+0 "Grooming Service" \
    -annotate +0+50 "Essex Mobile Unit" \
    -quality 85 images/dog-grooming-service.jpg

# Dog Bathing Service  
convert -size 800x600 xc:"$BRAND_GREEN" \
    -fill white -pointsize 48 -gravity center \
    -annotate +0-50 "Professional Dog" \
    -annotate +0+0 "Bathing Service" \
    -annotate +0+50 "Mobile Unit Essex" \
    -quality 85 images/dog-bathing-service.jpg

# Nail Trimming Service
convert -size 800x600 xc:"#8B4513" \
    -fill white -pointsize 48 -gravity center \
    -annotate +0-50 "Professional Nail" \
    -annotate +0+0 "Trimming Service" \
    -annotate +0+50 "Safe & Expert" \
    -quality 85 images/dog-nail-trimming-service.jpg

# De-shedding Service
convert -size 800x600 xc:"#FF8C00" \
    -fill white -pointsize 48 -gravity center \
    -annotate +0-50 "Professional" \
    -annotate +0+0 "De-shedding Treatment" \
    -annotate +0+50 "Before & After Results" \
    -quality 85 images/dog-de-shedding-service.jpg

# Dog Styling Service
convert -size 800x600 xc:"#9932CC" \
    -fill white -pointsize 48 -gravity center \
    -annotate +0-50 "Professional Dog" \
    -annotate +0+0 "Styling Service" \
    -annotate +0+50 "Breed Specific Cuts" \
    -quality 85 images/dog-styling-service.jpg

# Puppy Grooming Service
convert -size 800x600 xc:"#FFB6C1" \
    -fill "$TEXT_COLOR" -pointsize 48 -gravity center \
    -annotate +0-50 "Gentle Puppy" \
    -annotate +0+0 "Grooming Service" \
    -annotate +0+50 "First Groom Experience" \
    -quality 85 images/puppy-grooming-service.jpg

echo "Creating town-specific placeholder images..."

# Town Images with local character
# Chelmsford
convert -size 800x600 xc:"$BRAND_BLUE" \
    -fill white -pointsize 42 -gravity center \
    -annotate +0-75 "Mobile Dog Grooming" \
    -annotate +0-25 "CHELMSFORD" \
    -pointsize 32 \
    -annotate +0+25 "County Town Service" \
    -annotate +0+75 "CM1, CM2, CM3" \
    -quality 85 images/mobile-dog-grooming-chelmsford.jpg

# Brentwood  
convert -size 800x600 xc:"#DAA520" \
    -fill white -pointsize 42 -gravity center \
    -annotate +0-75 "Luxury Mobile Grooming" \
    -annotate +0-25 "BRENTWOOD" \
    -pointsize 32 \
    -annotate +0+25 "Premium Pet Care" \
    -annotate +0+75 "CM13, CM14, CM15" \
    -quality 85 images/mobile-dog-grooming-brentwood.jpg

# Romford
convert -size 800x600 xc:"#DC143C" \
    -fill white -pointsize 42 -gravity center \
    -annotate +0-75 "Mobile Dog Grooming" \
    -annotate +0-25 "ROMFORD" \
    -pointsize 32 \
    -annotate +0+25 "Historic Market Town" \
    -annotate +0+75 "RM1, RM2, RM3" \
    -quality 85 images/mobile-dog-grooming-romford.jpg

# Loughton
convert -size 800x600 xc:"#228B22" \
    -fill white -pointsize 42 -gravity center \
    -annotate +0-75 "Mobile Dog Grooming" \
    -annotate +0-25 "LOUGHTON" \
    -pointsize 32 \
    -annotate +0+25 "Epping Forest Gateway" \
    -annotate +0+75 "IG10 Areas" \
    -quality 85 images/mobile-dog-grooming-loughton.jpg

# Harlow
convert -size 800x600 xc:"#4169E1" \
    -fill white -pointsize 42 -gravity center \
    -annotate +0-75 "Modern Mobile Grooming" \
    -annotate +0-25 "HARLOW" \
    -pointsize 32 \
    -annotate +0+25 "Innovative New Town" \
    -annotate +0+75 "CM17, CM18, CM19, CM20" \
    -quality 85 images/mobile-dog-grooming-harlow.jpg

# Rayleigh
convert -size 800x600 xc:"#8B008B" \
    -fill white -pointsize 42 -gravity center \
    -annotate +0-75 "Mobile Dog Grooming" \
    -annotate +0-25 "RAYLEIGH" \
    -pointsize 32 \
    -annotate +0+25 "Historic Market Town" \
    -annotate +0+75 "SS6 Areas" \
    -quality 85 images/mobile-dog-grooming-rayleigh.jpg

# Basildon
convert -size 800x600 xc:"#FF6347" \
    -fill white -pointsize 42 -gravity center \
    -annotate +0-75 "Mobile Dog Grooming" \
    -annotate +0-25 "BASILDON" \
    -pointsize 32 \
    -annotate +0+25 "Modern New Town" \
    -annotate +0+75 "SS13, SS14, SS15, SS16" \
    -quality 85 images/mobile-dog-grooming-basildon.jpg

# Southend-on-Sea
convert -size 800x600 xc:"#008B8B" \
    -fill white -pointsize 42 -gravity center \
    -annotate +0-75 "Seaside Mobile Grooming" \
    -annotate +0-25 "SOUTHEND-ON-SEA" \
    -pointsize 32 \
    -annotate +0+25 "Coastal Pet Care" \
    -annotate +0+75 "SS0, SS1, SS2, SS3" \
    -quality 85 images/mobile-dog-grooming-southend.jpg

echo "Creating additional images..."

# Company Logo Placeholder
convert -size 400x200 xc:"$LIGHT_GREY" \
    -fill "$BRAND_BLUE" -pointsize 32 -gravity center \
    -annotate +0-30 "Spoilt N Pampered" \
    -annotate +0+0 "POOCHES" \
    -pointsize 18 \
    -annotate +0+30 "Mobile Dog Grooming Essex" \
    -quality 90 images/logo.png

# Solar Mobile Unit
convert -size 800x600 xc:"$BRAND_GREEN" \
    -fill white -pointsize 40 -gravity center \
    -annotate +0-50 "Eco-Friendly Solar" \
    -annotate +0+0 "Mobile Grooming Unit" \
    -annotate +0+50 "Sustainable Pet Care" \
    -quality 85 images/solar-mobile-grooming-unit.jpg

echo "Optimizing image sizes..."

# Create WebP versions for better compression
for img in images/*.jpg; do
    base=$(basename "$img" .jpg)
    if command -v cwebp &> /dev/null; then
        cwebp -q 80 "$img" -o "images/${base}.webp"
        echo "Created WebP version: images/${base}.webp"
    fi
done

# Check file sizes
echo "Checking file sizes (should be under 100KB)..."
ls -lh images/*.jpg images/*.webp 2>/dev/null | awk '{print $5, $9}'

echo "Placeholder images created successfully!"
echo "Remember to replace these with actual professional photographs before going live."