# Image Specifications for Spoilt N Pampered Pooches

## Image Requirements
- **File Size**: Under 100KB each
- **Format**: WebP preferred, JPEG fallback
- **Dimensions**: 800x600px (4:3 aspect ratio)
- **Compression**: Optimised for web without quality loss
- **Alt Text**: Descriptive and keyword-rich

## Service Images

### 1. Dog Grooming Service
**Filename**: `dog-grooming-service.jpg` / `dog-grooming-service.webp`
**Alt Text**: "Professional dog grooming service in Essex showing groomer with happy dog"
**Description**: Image showing professional groomer working on a well-behaved dog in mobile unit
**Keywords**: dog grooming, professional, Essex, mobile

### 2. Dog Bathing Service  
**Filename**: `dog-bathing-service.jpg` / `dog-bathing-service.webp`
**Alt Text**: "Professional dog bathing service in Essex mobile unit"
**Description**: Dog being bathed in mobile grooming unit with warm water and eco-friendly products
**Keywords**: dog bathing, mobile unit, professional, Essex

### 3. Nail Trimming Service
**Filename**: `dog-nail-trimming-service.jpg` / `dog-nail-trimming-service.webp`
**Alt Text**: "Professional dog nail trimming service being performed safely"
**Description**: Close-up of professional nail trimming being performed with proper technique
**Keywords**: nail trimming, professional, safe, dog care

### 4. De-shedding Service
**Filename**: `dog-de-shedding-service.jpg` / `dog-de-shedding-service.webp`
**Alt Text**: "Professional dog de-shedding treatment showing before and after results"
**Description**: Split image showing dog before and after de-shedding treatment
**Keywords**: de-shedding, treatment, professional, results

### 5. Dog Styling Service
**Filename**: `dog-styling-service.jpg` / `dog-styling-service.webp`
**Alt Text**: "Professional dog styling service showing beautifully styled poodle"
**Description**: Professionally styled poodle showcasing expert grooming skills
**Keywords**: dog styling, professional, poodle, grooming

### 6. Puppy Grooming Service
**Filename**: `puppy-grooming-service.jpg` / `puppy-grooming-service.webp`
**Alt Text**: "Gentle puppy grooming service with young dog being carefully handled"
**Description**: Young puppy receiving gentle grooming care with patient handling
**Keywords**: puppy grooming, gentle, young dog, care

## Town-Specific Images

### 1. Mobile Grooming Chelmsford
**Filename**: `mobile-dog-grooming-chelmsford.jpg` / `mobile-dog-grooming-chelmsford.webp`
**Alt Text**: "Mobile dog grooming van in Chelmsford providing professional pet care services"
**Description**: Solar-powered mobile unit parked in recognisable Chelmsford location
**Keywords**: mobile grooming, Chelmsford, van, professional

### 2. Mobile Grooming Brentwood  
**Filename**: `mobile-dog-grooming-brentwood.jpg` / `mobile-dog-grooming-brentwood.webp`
**Alt Text**: "Luxury mobile dog grooming service in Brentwood Essex"
**Description**: Premium mobile unit in upscale Brentwood residential area
**Keywords**: luxury, mobile grooming, Brentwood, Essex

### 3. Mobile Grooming Romford
**Filename**: `mobile-dog-grooming-romford.jpg` / `mobile-dog-grooming-romford.webp`
**Alt Text**: "Mobile dog grooming service in Romford Essex market town"
**Description**: Mobile unit in Romford with market town atmosphere visible
**Keywords**: mobile grooming, Romford, market town, Essex

### 4. Mobile Grooming Loughton
**Filename**: `mobile-dog-grooming-loughton.jpg` / `mobile-dog-grooming-loughton.webp`
**Alt Text**: "Mobile dog grooming service in Loughton near Epping Forest"
**Description**: Mobile unit with Epping Forest greenery in background
**Keywords**: mobile grooming, Loughton, Epping Forest

### 5. Mobile Grooming Harlow
**Filename**: `mobile-dog-grooming-harlow.jpg` / `mobile-dog-grooming-harlow.webp`
**Alt Text**: "Modern mobile dog grooming service in Harlow new town Essex"
**Description**: Contemporary mobile unit in modern Harlow setting
**Keywords**: modern, mobile grooming, Harlow, new town

### 6. Mobile Grooming Rayleigh
**Filename**: `mobile-dog-grooming-rayleigh.jpg` / `mobile-dog-grooming-rayleigh.webp`
**Alt Text**: "Mobile dog grooming service in historic Rayleigh Essex market town"
**Description**: Mobile unit in traditional Rayleigh market town setting
**Keywords**: mobile grooming, Rayleigh, historic, market town

### 7. Mobile Grooming Basildon
**Filename**: `mobile-dog-grooming-basildon.jpg` / `mobile-dog-grooming-basildon.webp`
**Alt Text**: "Professional mobile dog grooming service in Basildon new town Essex"
**Description**: Mobile unit in modern Basildon residential area
**Keywords**: professional, mobile grooming, Basildon, new town

### 8. Mobile Grooming Southend-on-Sea
**Filename**: `mobile-dog-grooming-southend.jpg` / `mobile-dog-grooming-southend.webp`
**Alt Text**: "Mobile dog grooming service in Southend-on-Sea Essex seaside city"
**Description**: Mobile unit with seaside/coastal elements visible
**Keywords**: mobile grooming, Southend-on-Sea, seaside, Essex

## Additional Images

### Company Logo
**Filename**: `logo.png` / `logo.webp`
**Alt Text**: "Spoilt N Pampered Pooches - Mobile Dog Grooming Essex Logo"
**Description**: Professional company logo with solar panel and dog elements
**Keywords**: logo, mobile dog grooming, Essex

### Solar Mobile Unit
**Filename**: `solar-mobile-grooming-unit.jpg` / `solar-mobile-grooming-unit.webp`
**Alt Text**: "Eco-friendly solar-powered mobile dog grooming unit Essex"
**Description**: Detailed view of solar panels on mobile grooming unit
**Keywords**: solar-powered, eco-friendly, mobile grooming

### Before/After Gallery
**Filename**: `before-after-grooming-[number].jpg`
**Alt Text**: "Dog grooming transformation showing before and after professional service"
**Description**: Split or side-by-side before/after grooming results
**Keywords**: before after, transformation, professional grooming

## Technical Specifications

### File Optimization
```
Original Size: 800x600px
WebP Quality: 80-85%
JPEG Quality: 85-90%
Target File Size: 60-95KB
Color Profile: sRGB
```

### Responsive Variants
```
Large: 800x600px (desktop)
Medium: 600x450px (tablet) 
Small: 400x300px (mobile)
Thumbnail: 200x150px (previews)
```

### SEO Optimization
- Descriptive filenames with keywords
- Alt text under 125 characters
- Title attributes for additional context
- Structured data integration
- Lazy loading implementation

## Implementation Notes

### HTML Structure
```html
<picture>
  <source srcset="image.webp" type="image/webp">
  <img src="image.jpg" 
       alt="Professional dog grooming service in Essex showing groomer with happy dog" 
       width="800" 
       height="600"
       loading="lazy">
</picture>
```

### CSS Optimization
```css
img {
  max-width: 100%;
  height: auto;
  object-fit: cover;
}
```

### Performance Considerations
- Critical images loaded immediately
- Below-fold images lazy loaded
- WebP format with JPEG fallback
- Appropriate srcset for responsive images
- Preload hints for important images

## Content Guidelines

### Photography Style
- Professional, high-quality images
- Consistent lighting and colour palette
- Clean, uncluttered backgrounds
- Happy, well-groomed dogs as subjects
- Mobile unit prominently featured

### Brand Consistency
- Company colours and branding visible
- Professional appearance maintained
- Consistent visual style across all images
- Logo placement where appropriate
- Clean, modern aesthetic

### Accessibility
- High contrast for visibility
- Clear subject matter
- Meaningful alt text descriptions
- Compatible with screen readers
- Appropriate colour choices for colourblind users